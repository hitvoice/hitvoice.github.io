function diff = compare(a,b)
diff = 0.0;
a = double(a)/255;
b = double(b)/255;
for i=1:numel(a)
    diff = diff + (a(i)-b(i))*(a(i)-b(i));
end
diff = sqrt(diff);