## Genetic Algorithm
This is a video illustration of Genetic Algorithm. The program learns to draw a picture using straight lines modeling after the given one. Starting & ending points and linewidths are parameters controlable by the genetic program. After several evolutions, the program will learn to draw well.

* main.m
Run the algorithm, see the curve of losses, and see the program's final artwork.
* video.m
Run the algorithm generation-by-generation, and watch a 25-fps video to see how the program learns to do it.

## 遗传算法

这是遗传算法的一个演示。程序模拟了一个自动作画的过程，通过优化笔刷的起止位置和粗细来绘制接近给定目标图像的图像。
两个可执行的matlab脚本是main.m和video.m：
* main.m
运行完整的遗传算法，显示目标函数随着迭代次数变化的曲线，并显示程序最终绘制的图像。
* video.m
逐代运行遗传算法，并利用每一代的最优图像生成进化过程的视频。视频的帧率为25帧/秒。
