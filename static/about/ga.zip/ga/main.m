addpath('./');
imgpath = input('enter image path: ','s');
k = input('enter the number of strokes: ');
img = rgb2gray(imread(imgpath));
[h,w] = size(img);
% define ga parameters
fitnessfcn = @(x) compare(img,render(x,w,h));
nvars = 5*k;
LB = zeros(nvars,1);
for i=1:k
    start = 5*i-5;
    LB(start+1) = 1;
    LB(start+2) = 1;
    LB(start+3) = 1;
    LB(start+4) = 1;
    LB(start+5) = 2;
end
UB = zeros(nvars,1);
for i=1:k
    start = 5*i-5;
    UB(start+1) = w;
    UB(start+2) = h;
    UB(start+3) = w;
    UB(start+4) = h;
    UB(start+5) = 10;
end
IntCon = 1:nvars;
options = gaoptimset('Display','iter','PlotFcns',@gaplotbestf);
    
brushes = ga(fitnessfcn,nvars,[],[],[],[],LB,UB,[],IntCon,options);
painting = render(brushes,w,h);
figure,imshow(painting);